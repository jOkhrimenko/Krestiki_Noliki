﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.but1 = new System.Windows.Forms.Button();
            this.but2 = new System.Windows.Forms.Button();
            this.but5 = new System.Windows.Forms.Button();
            this.but9 = new System.Windows.Forms.Button();
            this.but6 = new System.Windows.Forms.Button();
            this.but3 = new System.Windows.Forms.Button();
            this.but7 = new System.Windows.Forms.Button();
            this.but8 = new System.Windows.Forms.Button();
            this.but4 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.choosePlayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // but1
            // 
            this.but1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but1.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but1.Location = new System.Drawing.Point(19, 34);
            this.but1.Name = "but1";
            this.but1.Size = new System.Drawing.Size(130, 130);
            this.but1.TabIndex = 0;
            this.but1.UseVisualStyleBackColor = false;
            this.but1.Click += new System.EventHandler(this.button_Click);
            // 
            // but2
            // 
            this.but2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but2.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but2.Location = new System.Drawing.Point(169, 34);
            this.but2.Name = "but2";
            this.but2.Size = new System.Drawing.Size(130, 130);
            this.but2.TabIndex = 1;
            this.but2.UseVisualStyleBackColor = false;
            this.but2.Click += new System.EventHandler(this.button_Click);
            // 
            // but5
            // 
            this.but5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but5.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but5.Location = new System.Drawing.Point(169, 180);
            this.but5.Name = "but5";
            this.but5.Size = new System.Drawing.Size(130, 130);
            this.but5.TabIndex = 2;
            this.but5.UseVisualStyleBackColor = false;
            this.but5.Click += new System.EventHandler(this.button_Click);
            // 
            // but9
            // 
            this.but9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but9.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but9.Location = new System.Drawing.Point(324, 328);
            this.but9.Name = "but9";
            this.but9.Size = new System.Drawing.Size(130, 130);
            this.but9.TabIndex = 3;
            this.but9.UseVisualStyleBackColor = false;
            this.but9.Click += new System.EventHandler(this.button_Click);
            // 
            // but6
            // 
            this.but6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but6.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but6.Location = new System.Drawing.Point(324, 180);
            this.but6.Name = "but6";
            this.but6.Size = new System.Drawing.Size(130, 130);
            this.but6.TabIndex = 5;
            this.but6.UseVisualStyleBackColor = false;
            this.but6.Click += new System.EventHandler(this.button_Click);
            // 
            // but3
            // 
            this.but3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but3.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but3.Location = new System.Drawing.Point(324, 34);
            this.but3.Name = "but3";
            this.but3.Size = new System.Drawing.Size(130, 130);
            this.but3.TabIndex = 6;
            this.but3.UseVisualStyleBackColor = false;
            this.but3.Click += new System.EventHandler(this.button_Click);
            // 
            // but7
            // 
            this.but7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but7.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but7.Location = new System.Drawing.Point(19, 328);
            this.but7.Name = "but7";
            this.but7.Size = new System.Drawing.Size(130, 130);
            this.but7.TabIndex = 7;
            this.but7.UseVisualStyleBackColor = false;
            this.but7.Click += new System.EventHandler(this.button_Click);
            // 
            // but8
            // 
            this.but8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but8.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but8.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but8.Location = new System.Drawing.Point(169, 328);
            this.but8.Name = "but8";
            this.but8.Size = new System.Drawing.Size(130, 130);
            this.but8.TabIndex = 8;
            this.but8.UseVisualStyleBackColor = false;
            this.but8.Click += new System.EventHandler(this.button_Click);
            // 
            // but4
            // 
            this.but4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(220)))), ((int)(((byte)(180)))));
            this.but4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.but4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but4.Font = new System.Drawing.Font("Rockwell", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.but4.Location = new System.Drawing.Point(19, 180);
            this.but4.Name = "but4";
            this.but4.Size = new System.Drawing.Size(130, 130);
            this.but4.TabIndex = 4;
            this.but4.UseVisualStyleBackColor = false;
            this.but4.Click += new System.EventHandler(this.button_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(489, 28);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.choosePlayerToolStripMenuItem,
            this.restartToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(62, 24);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // choosePlayerToolStripMenuItem
            // 
            this.choosePlayerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xToolStripMenuItem,
            this.oToolStripMenuItem});
            this.choosePlayerToolStripMenuItem.Name = "choosePlayerToolStripMenuItem";
            this.choosePlayerToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.choosePlayerToolStripMenuItem.Text = "ChoosePlayer";
            this.choosePlayerToolStripMenuItem.Click += new System.EventHandler(this.choosePlayerToolStripMenuItem_Click);
            // 
            // xToolStripMenuItem
            // 
            this.xToolStripMenuItem.Name = "xToolStripMenuItem";
            this.xToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.xToolStripMenuItem.Text = "X";
            this.xToolStripMenuItem.Click += new System.EventHandler(this.xToolStripMenuItem_Click);
            // 
            // oToolStripMenuItem
            // 
            this.oToolStripMenuItem.Name = "oToolStripMenuItem";
            this.oToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.oToolStripMenuItem.Text = "O";
            this.oToolStripMenuItem.Click += new System.EventHandler(this.oToolStripMenuItem_Click);
            // 
            // restartToolStripMenuItem
            // 
            this.restartToolStripMenuItem.Name = "restartToolStripMenuItem";
            this.restartToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.restartToolStripMenuItem.Text = "Restart";
            this.restartToolStripMenuItem.Click += new System.EventHandler(this.restartToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 476);
            this.Controls.Add(this.but8);
            this.Controls.Add(this.but7);
            this.Controls.Add(this.but3);
            this.Controls.Add(this.but6);
            this.Controls.Add(this.but4);
            this.Controls.Add(this.but9);
            this.Controls.Add(this.but5);
            this.Controls.Add(this.but2);
            this.Controls.Add(this.but1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.Info;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Kółko i krzyżyk";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button but1;
        private System.Windows.Forms.Button but2;
        private System.Windows.Forms.Button but5;
        private System.Windows.Forms.Button but9;
        private System.Windows.Forms.Button but6;
        private System.Windows.Forms.Button but3;
        private System.Windows.Forms.Button but7;
        private System.Windows.Forms.Button but8;
        private System.Windows.Forms.Button but4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem choosePlayerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restartToolStripMenuItem;
    }
}

